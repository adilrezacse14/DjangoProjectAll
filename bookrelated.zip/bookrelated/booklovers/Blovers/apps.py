from django.apps import AppConfig


class BloversConfig(AppConfig):
    name = 'Blovers'
