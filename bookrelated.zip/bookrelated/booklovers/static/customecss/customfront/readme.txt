OTF and TTF: Funkrocker
Dennis Ludlow 2015 all rights reserved
by Sharkshock 
dennis@sharkshock.net

OK people It's time to get FUNKY. Meet Funkrocker; a grunge inspired typeface guaranteed to add some flavor to your creative soup. The glyphs are "rough around the edges" yet easy on the eyes. This urban display font features basic latin, supplemental latin, punctuation, European accents, 
and Cyrillic characters for Russian and Ukranian. Alternate uppercase letters are available if your editing program supports OTF. Use Funkrocker for album art, titles, or a poster. 

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info. I also design custom fonts for 
businesses, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 


visit www.sharkshock.net for more and take a bite out of BORING design!

