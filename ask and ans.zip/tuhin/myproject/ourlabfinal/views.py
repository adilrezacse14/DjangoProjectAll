from django.shortcuts import render
from .models import registrationList
from .models import allpost
from .models import replaylist
from django.utils import timezone

import datetime
from datetime import datetime
from django.http import Http404
from django.contrib import messages

# Create your views here.

def homepage(request):
	return render(request, 'index.html')
def registration(request):
	if request.method=="GET":
		return render(request, 'registration.html')
	elif request.method=="POST":
		uname=request.POST.get('fullname')
		umail=request.POST.get('gmail')
		upass1=request.POST.get('pass1')
		upass2=request.POST.get('pass2')
		uvarsity=request.POST.get('varsity')
		uexpert=request.POST.get('expert')
		now = datetime.now()
		
		sql=registrationList(username=uname,usermail=umail,pass1=upass1,pass2=upass2,varsity=uvarsity,experties=uexpert)
		sql.save()
		
		contextt="ok"
		makedictionary={
			'msgreg':contextt
		}
		return render(request, 'registration.html', context=makedictionary)
	else:
		return render(request, 'index.html')
		
		
		
def login(request):
	if request.method=="GET":
		return render(request, 'login.html')
	elif request.method=="POST":
		ugmail=request.POST.get('loggmail')
		upass=request.POST.get('logpass')
		context=registrationList.objects.filter(usermail=ugmail)
		if context.count()==0:
			contextt="ok"
			makedictionary={
			'msgrlog2':contextt
			}
			return render(request, 'login.html',context=makedictionary)
		
		contextt="ok"
		makedictionary={
			'msgrlog':contextt
		}
		
		for i in context:
			if(i.pass1==upass):
				
				
				request.session['wow']=request.POST['loggmail'];
				
				contextt="ok"
				makedictionary={
				'msgrlog':contextt
				}
				return render(request, 'login.html',context=makedictionary)
			else:
				contextt="ok"
				makedictionary={
				'msgrlog2':contextt
				}
				return render(request, 'login.html',context=makedictionary)
		
				
	else:
		contextt="no"
		makedictionary={
		'msgrlog2':contextt
		}
		return render(request, 'registration',context=makedictionary)
				
def mainpage(request):
	if request.method=="GET":
		if 'wow' in request.session:
			allcontent=allpost.objects.all().order_by('postid').reverse()
			makedictionary={
				'contents':allcontent
			}
			return render(request, 'mainpage.html',context=makedictionary)
		else:
			return render(request, 'registration.html')
			
		
		
		
def postingpage(request):
	if request.method=="GET":
		return render(request, 'postingpage.html')
	elif request.method=="POST":
		mypostt=request.POST.get('mypost')
		pmaill=request.POST.get('pmail')
		myposttitle=request.POST.get('myposttt')
		
		if(pmaill!=""):
			pretotal=allpost.objects.count();
			posttotal=0;
			query=allpost.objects.all()
			
			for i in query:
				posttotal=i.id
			
			sql=allpost(postid=posttotal,postermail=pmaill, posttile=myposttitle, postdetails=mypostt, datetimm=datetime.now())
			sql.save()
			
			contextt="ok"
			makedictionary={
			'user555':contextt
			}
			return render(request, 'postingpage.html', context=makedictionary);
		else:
			contextt="no"
			makedictionary={
			'notuser':contextt
			}
			return render(request, 'postingpage.html', context=makedictionary);
	else:
		return render(request, "index.html")
		

def finalpage(request):
	if request.method=="GET":
		return render(request, 'finalpage.html')
	elif request.method=="POST":
		dynamicid=request.POST.get('dynamicpostid')
		selectedcontent=allpost.objects.filter(postid=dynamicid)
		
		
		replaycontent=replaylist.objects.filter(mainpostid=dynamicid).order_by('id').reverse()
		
		# raise Http404
		# post=allpost.objects.get(postid=dynamicid)
		# post.delete()
		
		makedictionary={
			'question':selectedcontent,
			'replaylistt':replaycontent,
		}
		return render(request, 'finalpage.html', context=makedictionary)
	else:
		return render(request, 'index.html')
		
		
		
def finaldestination(request):
	if request.method=="GET":
		return render(request, 'mainpage.html')
	elif request.method=="POST":
		dynamicid=request.POST.get('dynamicpostid')
		selectedcontent=allpost.objects.filter(postid==dynamicid)
		return render(request, 'index.html')
		
		
		
def replaypage(request):
	if request.method=="GET":
		return render(request, 'replaypage.html')
	elif request.method=="POST":
		questionno=request.POST.get('question');
		replaymail=request.POST.get('maill')
		allcontent=allpost.objects.filter(postid=questionno)
		makedictionary={
			'aboutquestion':allcontent
		}
		return render(request, 'replaypage.html',context=makedictionary)
		
		
def replaypagefinal(request):
	if request.method=="POST":
		questionno=request.POST.get('questionno')
		replaydetails=request.POST.get('mypost')
		gmail=request.POST.get('gmail')
		
		sql=replaylist(mainpostid=questionno, replyusermail=gmail, replayans=replaydetails,datetimm=datetime.now())
		sql.save()
		allcontent=allpost.objects.all().order_by('postid').reverse()
		makedictionary={
			'contents':allcontent
		}
		return render(request, 'mainpage.html',context=makedictionary)
	
def delete(request):
	deletid=request.POST.get('deletid')
	
	post=replaylist.objects.get(mainpostid=deletid)
	post2=replaylist.objects.filter(mainpostid=deletid)
	umail=""
	
	for i in post2:
		umail=i.replyusermail
	if umail==request.session['wow']:
		post.delete()
		if 'wow' in request.session:
			allcontent=allpost.objects.all().order_by('postid').reverse()
			makedictionary={
				'contents':allcontent
			}
			return render(request, 'mainpage.html',context=makedictionary)
	else:
		if 'wow' in request.session:
			allcontent=allpost.objects.all().order_by('postid').reverse()
			makedictionary={
				'contents':allcontent
			}
			return render(request, 'mainpage.html',context=makedictionary)