from django.apps import AppConfig


class OurlabfinalConfig(AppConfig):
    name = 'ourlabfinal'
