from django.db import models


# Create your models here.
class registrationList(models.Model):
	username=models.CharField(max_length=300,)
	usermail=models.CharField(max_length=300, blank=False)
	pass1=models.CharField(max_length=32)
	pass2=models.CharField(max_length=32)
	varsity=models.CharField(max_length=100)
	experties=models.CharField(max_length=200)
	
class allpost(models.Model):
	postid=models.IntegerField(blank=False)
	postermail=models.CharField(blank=False, max_length=200)
	posttile=models.CharField(max_length=200)
	postdetails=models.TextField(max_length=1000)
	datetimm = models.CharField(max_length=100)
	
class replaylist(models.Model):
	mainpostid=models.IntegerField(blank=False)
	replyusermail=models.CharField(blank=False, max_length=100)
	replayans=models.CharField(max_length=900)
	datetimm = models.CharField(max_length=100)