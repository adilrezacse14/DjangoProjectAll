from django.db import models

# Create your models here.
class doctorlist(models.Model):
	name=models.CharField(max_length=200)
	designation=models.CharField(max_length=200)
	degree=models.CharField(max_length=200)
	experienced=models.TextField()
	
	
	
	def __str__(self):
		return self.name

class doctorlistwithplace(models.Model):
	name=models.CharField(max_length=200)
	designation=models.CharField(max_length=200)
	degree=models.CharField(max_length=200)
	experienced=models.TextField()
	placehold=models.CharField(max_length=200)
	
	
	
	def __str__(self):
		return self.name