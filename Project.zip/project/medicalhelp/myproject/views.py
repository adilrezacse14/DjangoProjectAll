from django.shortcuts import render
from .models import doctorlistwithplace

# Create your views here.
def index(request):
	return render (request, 'index.html')
def hospitallist(request):
	return render(request, 'diagnostic.html')

def about(request):
	return render(request, 'about.html')

def showlist(request):
		tt=request.POST.get('indicator', '')
		content=doctorlistwithplace.objects.filter(placehold=tt)
		contexttt={
			'list':content
		}
		return render(request, 'showlist.html', context=contexttt)