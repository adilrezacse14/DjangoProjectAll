from django.contrib import admin
from .models import doctorlist
from .models import doctorlistwithplace
# Register your models here.
class doctorlist_Admin(admin.ModelAdmin):
	list_display = ['name', 'designation','degree','experienced']
	class Meta:
		model = doctorlist
admin.site.register(doctorlist, doctorlist_Admin)

class doctorlistwithplace_Admin(admin.ModelAdmin):
	list_display = ['name', 'designation','degree','experienced','placehold']
	class Meta:
		model = doctorlistwithplace
admin.site.register(doctorlistwithplace, doctorlistwithplace_Admin)